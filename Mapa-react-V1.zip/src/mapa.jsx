import React, { useState, useRef, useEffect } from "react";
import "./style.css";

const CELL_SIZE = 40;
const ROWS = 10;
const COLS = 10;
const STATUS_COLORS = {
  active: "rgba(0, 128, 0, 0.6)",
  reserved: "rgba(255, 165, 0, 0.6)",
  blocked: "rgba(255, 0, 0, 0.6)",
};

const ReservationEditor = () => {
  const [reservations, setReservations] = useState([]);
  const [startCell, setStartCell] = useState(null);
  const [hoverCell, setHoverCell] = useState(null);
  const [isDragging, setIsDragging] = useState(false);
  const [draggedIndex, setDraggedIndex] = useState(null);
  const [resizingIndex, setResizingIndex] = useState(null);
  const [selectedIndex, setSelectedIndex] = useState(null);
  const gridRef = useRef(null);
  const dragTimer = useRef(0);

  const getCellCoords = (e) => {
    const rect = gridRef.current.getBoundingClientRect();
    const x = Math.floor((e.clientX - rect.left) / CELL_SIZE);
    const y = Math.floor((e.clientY - rect.top) / CELL_SIZE);
    return { x, y };
  };

  const rectanglesOverlap = (a, b) => (
    a.x < b.x + b.w &&
    a.x + a.w > b.x &&
    a.y < b.y + b.h &&
    a.y + a.h > b.y
  );

  const hasCollision = (newRect, ignoreIndex = -1) => (
    reservations.some((r, i) => i !== ignoreIndex && rectanglesOverlap(newRect, r))
  );

  const handleMouseDown = (e) => {
    if (e.button !== 0) return;
    if (e.target.closest("select")) return;

    const { x, y } = getCellCoords(e);
    const resIndex = reservations.findIndex(
      (r) => x >= r.x && x < r.x + r.w && y >= r.y && y < r.y + r.h
    );

    if (e.target.classList.contains("resize-handle")) {
      setResizingIndex(resIndex);
    } else if (resIndex !== -1) {
      setDraggedIndex(resIndex);
      setSelectedIndex(resIndex);
    } else {
      setStartCell({ x, y });
      setIsDragging(true);
      setSelectedIndex(null);
    }
  };

  const handleMouseMove = (e) => {
    const now = Date.now();
    if (now - dragTimer.current < 100) return;
    dragTimer.current = now;

    const coords = getCellCoords(e);
    if (isDragging) {
      setHoverCell(coords);
    } else if (draggedIndex !== null) {
      setReservations((prev) => {
        const updated = [...prev];
        const res = updated[draggedIndex];
        const nextRect = { ...res, x: coords.x, y: coords.y };
        if (
          nextRect.x >= 0 &&
          nextRect.y >= 0 &&
          nextRect.x + res.w <= COLS &&
          nextRect.y + res.h <= ROWS &&
          !hasCollision(nextRect, draggedIndex)
        ) {
          updated[draggedIndex] = nextRect;
        }
        return updated;
      });
    } else if (resizingIndex !== null) {
      setReservations((prev) => {
        const updated = [...prev];
        const res = updated[resizingIndex];
        const newW = Math.max(1, coords.x - res.x + 1);
        const newH = Math.max(1, coords.y - res.y + 1);
        const nextRect = { ...res, w: newW, h: newH };
        if (
          nextRect.x >= 0 &&
          nextRect.y >= 0 &&
          nextRect.x + nextRect.w <= COLS &&
          nextRect.y + nextRect.h <= ROWS &&
          !hasCollision(nextRect, resizingIndex)
        ) {
          updated[resizingIndex] = nextRect;
        }
        return updated;
      });
    }
  };

  const handleMouseUp = () => {
    if (isDragging && startCell && hoverCell) {
      const x = Math.min(startCell.x, hoverCell.x);
      const y = Math.min(startCell.y, hoverCell.y);
      const w = Math.abs(startCell.x - hoverCell.x) + 1;
      const h = Math.abs(startCell.y - hoverCell.y) + 1;
      const newRect = { x, y, w, h };
      if (
        x >= 0 && y >= 0 &&
        x + w <= COLS && y + h <= ROWS &&
        !hasCollision(newRect)
      ) {
        setReservations([...reservations, {
          ...newRect,
          name: `Rezervace ${reservations.length + 1}`,
          status: 'active',
        }]);
      }
    }
    setStartCell(null);
    setHoverCell(null);
    setIsDragging(false);
    setDraggedIndex(null);
    setResizingIndex(null);
  };

  const handleRightClick = (e, i) => {
    e.preventDefault();
    const updated = [...reservations];
    updated.splice(i, 1);
    setReservations(updated);
    if (selectedIndex === i) setSelectedIndex(null);
  };

  const handleStatusChange = (i, newStatus) => {
    setReservations((prev) => {
      const updated = [...prev];
      updated[i] = { ...updated[i], status: newStatus };
      return updated;
    });
  };

  const handleDeleteSelected = () => {
    if (selectedIndex !== null) {
      const updated = [...reservations];
      updated.splice(selectedIndex, 1);
      setReservations(updated);
      setSelectedIndex(null);
    }
  };

  return (
    <div style={{ display: "flex", gap: "20px", userSelect: "none" }}>
      <div>
        <div className="legend">
          <span style={{ backgroundColor: STATUS_COLORS.active }}>Aktivní</span>
          <span style={{ backgroundColor: STATUS_COLORS.reserved }}>Rezervováno</span>
          <span style={{ backgroundColor: STATUS_COLORS.blocked }}>Blokováno</span>
        </div>
        <button onClick={handleDeleteSelected} disabled={selectedIndex === null}>
          Smazat vybranou rezervaci
        </button>

        <div
          ref={gridRef}
          className="grid"
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onContextMenu={(e) => e.preventDefault()}
        >
          {[...Array(ROWS)].map((_, y) =>
            [...Array(COLS)].map((_, x) => (
              <div
                key={`${x}-${y}`}
                className="cell"
                style={{ width: CELL_SIZE, height: CELL_SIZE }}
              />
            ))
          )}

          {reservations.map((res, i) => (
            <div
              key={i}
              className={`reservation ${res.status}`}
              onContextMenu={(e) => handleRightClick(e, i)}
              style={{
                left: res.x * CELL_SIZE,
                top: res.y * CELL_SIZE,
                width: res.w * CELL_SIZE,
                height: res.h * CELL_SIZE,
                backgroundColor: STATUS_COLORS[res.status],
                cursor: "move",
                border: i === selectedIndex ? "2px solid black" : "none",
                fontSize: 12,
                textAlign: "center",
                transition: "left 0.1s linear, top 0.1s linear",
              }}
            >
              {i + 1}
              <select
                className="status-select"
                value={res.status}
                onChange={(e) => handleStatusChange(i, e.target.value)}
                onMouseDown={(e) => e.stopPropagation()}
              >
                <option value="active">Aktivní</option>
                <option value="reserved">Rezervováno</option>
                <option value="blocked">Blokováno</option>
              </select>
              <div
                className="resize-handle"
                style={{
                  position: "absolute",
                  right: 0,
                  bottom: 0,
                  width: 10,
                  height: 10,
                  backgroundColor: "white",
                  border: "1px solid black",
                  cursor: "nwse-resize",
                }}
              />
            </div>
          ))}

          {isDragging && startCell && hoverCell && (
            <div
              className="reservation draft"
              style={{
                left: Math.min(startCell.x, hoverCell.x) * CELL_SIZE,
                top: Math.min(startCell.y, hoverCell.y) * CELL_SIZE,
                width: (Math.abs(startCell.x - hoverCell.x) + 1) * CELL_SIZE,
                height: (Math.abs(startCell.y - hoverCell.y) + 1) * CELL_SIZE,
                backgroundColor: "rgba(0, 128, 0, 0.3)",
                pointerEvents: "none",
              }}
            />
          )}
        </div>
      </div>

      <div style={{ width: "250px" }}>
        <h4>Seznam rezervací</h4>
        <ul>
          {reservations.map((res, i) => (
            <li
              key={i}
              onClick={() => setSelectedIndex(i)}
              style={{
                cursor: "pointer",
                background: i === selectedIndex ? "#e0e0e0" : "transparent",
                padding: "4px",
              }}
            >
              <strong>{i + 1}.</strong> {res.name} ({res.w}×{res.h}) [{res.status}]
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default ReservationEditor;
