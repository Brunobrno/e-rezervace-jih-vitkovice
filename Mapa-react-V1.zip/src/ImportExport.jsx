// --- začátek ---
import React, { useState, useRef, useEffect } from "react";
import "./style.css";

const CELL_SIZE = 40;
const ROWS = 10;
const COLS = 10;
const PRICE_PER_M2 = 100;
const GRID_RESOLUTION = 1;

const STATUS_COLORS = {
  active: "rgba(0, 128, 0, 0.6)",
  reserved: "rgba(255, 165, 0, 0.6)",
  blocked: "rgba(255, 0, 0, 0.6)",
};

const calculatePrice = (w, h) => (w * GRID_RESOLUTION) * (h * GRID_RESOLUTION) * PRICE_PER_M2;

const generateApiPayload = (reservations, userId = 0, eventId = 0) => {
  const now = new Date().toISOString();
  return reservations.map((r, i) => {
    const cells = [];
    for (let dx = 0; dx < r.w; dx++) {
      for (let dy = 0; dy < r.h; dy++) {
        cells.push({
          x: r.x + dx,
          y: r.y + dy,
          w: 1,
          h: 1,
          reservation: i
        });
      }
    }
    return {
      user: userId,
      event: eventId,
      reserved_from: now,
      reserved_to: now,
      status: r.status === "blocked" ? "cancelled" : "reserved",
      note: r.name,
      cells
    };
  });
};

// --- export/import JSON ---
const downloadJSON = (reservations) => {
  const payload = generateApiPayload(reservations);
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = "reservations.json";
  link.click();
};

const uploadJSON = (e, setReservations) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (event) => {
    try {
      const data = JSON.parse(event.target.result);
      const restored = data.map((r, i) => {
        const bounds = r.cells.reduce((acc, cell) => {
          acc.minX = Math.min(acc.minX, cell.x);
          acc.minY = Math.min(acc.minY, cell.y);
          acc.maxX = Math.max(acc.maxX, cell.x);
          acc.maxY = Math.max(acc.maxY, cell.y);
          return acc;
        }, { minX: Infinity, minY: Infinity, maxX: -Infinity, maxY: -Infinity });
        const w = bounds.maxX - bounds.minX + 1;
        const h = bounds.maxY - bounds.minY + 1;
        return {
          x: bounds.minX,
          y: bounds.minY,
          w,
          h,
          name: r.note || `Rezervace ${i + 1}`,
          status: r.status === "cancelled" ? "blocked" : "reserved",
          locked: false,
          price: calculatePrice(w, h),
        };
      });
      setReservations(restored);
    } catch (err) {
      alert("Neplatný JSON formát.");
    }
  };
  reader.readAsText(file);
};

// --- konec rozšíření ---

// --- export/import UI komponenta ---
const JsonImportExport = ({ reservations, setReservations }) => (
  <div style={{ marginTop: '1em' }}>
    <h4>Export / Import</h4>
    <button onClick={() => downloadJSON(reservations)}>📤 Exportovat JSON</button>
    <br />
    <input
      type="file"
      accept="application/json"
      onChange={(e) => uploadJSON(e, setReservations)}
      style={{ marginTop: '0.5em' }}
    />
  </div>
);

export { JsonImportExport };
