import React, { useState } from "react";
import ReservationEditor from './mapa.jsx';
import { JsonImportExport } from "./ImportExport";




export function App(props) {
  const [reservations, setReservations] = useState([]); // <- definujeme zde

  return (
    <div className='App'>
      <ReservationEditor
        reservations={reservations}
        setReservations={setReservations}
      />
      <JsonImportExport
        reservations={reservations}
        setReservations={setReservations}
      />
    </div>
  );
}

// Log to console
console.log('Hello console');
